package test;

import gui.GameArea;
import gui.UnitIcon;
import gui.Window;
import main.Main;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.testng.Assert;
import units.Battle;
import units.Cavalry;
import units.Infantry;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

public class Tests {

    @BeforeEach
    public void beforeTests(){
        Main.window = new Window("Test", 1280, 720);
        Main.window.init();
        Main.window.inMenu();
    }

    @Test
    public void testSetupBattle(){
        Main.window.startGame();
        Assert.assertEquals(Main.playerUnits.size(), 3);
        Assert.assertEquals(Main.enemyUnits.size(), 3);
        Assert.assertEquals(Main.playerUnits.get(1).toString(), "Cavalry 30 30 1 280 600 2 -1.5707963705062866 line");
    }

    @Test
    public void testSave(){
        Main.window.saveGame();
        try {
            BufferedReader reader = new BufferedReader(new FileReader("save.txt"));
            List<String> lines = reader.lines().toList();
            Assert.assertEquals(lines.get(2), "Cavalry 30 30 1 280 600 2 -1.5707963705062866 line");
            reader.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testLoad(){
        Assert.assertEquals(Main.playerUnits.size(), 0);
        Assert.assertEquals(Main.enemyUnits.size(), 0);
        Main.window.loadGame();
        Assert.assertEquals(Main.playerUnits.size(), 3);
        Assert.assertEquals(Main.enemyUnits.size(), 3);
    }

    @Test
    public void testBattle(){
        Infantry infantry = new Infantry(30, 30, 1, 200, 600, 1, -1.57f, null);
        Cavalry cavalry = new Cavalry(30, 30, 1, 255, 179, 2, 1.588f, null);
        Battle battle = new Battle(infantry, cavalry);
        battle.start();
        Assert.assertEquals(infantry.calculateDemageAgainst(cavalry), 6);
        try {
            battle.join();
            Assert.assertNull(battle.enemyUnit);
            Assert.assertNotNull(battle.playerUnit);
        }
        catch (InterruptedException e){
            e.printStackTrace();
        }
    }

    @Test
    public void testMenu(){
        Main.window.inMenu();
        Assert.assertEquals(Main.window.getCurrentCard(), "MainMenu");
        Main.window.inSetupMenu();
        Assert.assertEquals(Main.window.getCurrentCard(), "SetupMenu");
        Main.window.startGame();
        Assert.assertEquals(Main.window.getCurrentCard(), "GameArea");
    }

    @Test
    public void testMoveOrder(){
        Infantry infantry = new Infantry(30, 30, 1, 200, 600, 1, -1.57f, null);
        infantry.moveCommand(new Point(100, 100));
        Point previousPoint = infantry.getPos();
        Assert.assertEquals(infantry.getPos().x, previousPoint.x);
        Assert.assertEquals(infantry.getPos().y, previousPoint.y);
        for(int i = 0; i < 200; i++){
            infantry.animate();
        }
        Assert.assertNotEquals(infantry.getPos().x, previousPoint.x);
        Assert.assertNotEquals(infantry.getPos().y, previousPoint.y);
    }

    @Test
    public void testUnitSelection(){
        GameArea area = new GameArea();
        Infantry infantry = new Infantry(30, 30, 1, 200, 600, 1, -1.57f, null);
        Main.playerUnits.clear();
        Main.playerUnits.add(infantry);
        area.addUnits(Main.playerUnits);
        area.mouseClicked(new MouseEvent(area, MouseEvent.MOUSE_CLICKED, System.currentTimeMillis(), 0, 200, 600, 1, false, MouseEvent.BUTTON1));
        Assert.assertEquals(area.getSelected(), infantry);
        area.mouseClicked(new MouseEvent(area, MouseEvent.MOUSE_CLICKED, System.currentTimeMillis(), 0, 100, 500, 1, false, MouseEvent.BUTTON3));
        Assert.assertNull(area.getSelected());
    }

    @Test
    public void testIconLoad(){
        UnitIcon icon = new UnitIcon("ArcherIcon.jpg");
        Assert.assertNotNull(icon.image);
    }

    @Test
    public void testTimer(){
        GameArea area = new GameArea();
        area.start();
        Assert.assertTrue(area.getT().isRunning());
        area.pause();
        Assert.assertFalse(area.getT().isRunning());
        area.pause();
        Assert.assertTrue(area.getT().isRunning());
        area.stopGame();
        Assert.assertFalse(area.getT().isRunning());
    }
}
