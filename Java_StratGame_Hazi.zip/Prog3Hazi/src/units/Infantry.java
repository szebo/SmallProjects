package units;

import gui.UnitIcon;

public class Infantry extends Unit {

    private Formation formation;

    public Infantry(int size, int baseDamage, int xp, int posX, int posY, int speed, float direction, UnitIcon icon) {
        super(size, baseDamage, xp, posX, posY, speed, direction, icon);
        formation = Formation.line;
    }

    /**
     * Modifies the default damage calculation according to the Infantry rules.
     * @param target
     * @return
     */
    @Override
    public int calculateDemageAgainst(Unit target) {
        int res = super.calculateDemageAgainst(target);
        if(target.getClass() == Cavalry.class) res += 5;
        if(target.getFormation() == Formation.shieldwall) res -= 1;
        if(formation == Formation.shieldwall) res -= 1;
        return res;
    }

    public Formation getFormation(){
        return this.formation;
    }

    public void setFormation(int form){
        if(form == 4) formation = Formation.line;
        else if(form == 5) formation = Formation.box;
        else formation = Formation.shieldwall;
    }

    public String toString(){
        return "Infantry "+size+" "+baseDamage+" "+xp+" "+posX+" "+posY+" "+speed+" "+direction+" "+formation;
    }
}
