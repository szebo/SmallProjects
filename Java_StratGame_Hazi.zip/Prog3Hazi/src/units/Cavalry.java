package units;

import gui.UnitIcon;

public class Cavalry extends Unit {

    private Formation formation;

    public Cavalry(int size, int baseDamage, int xp, int posX, int posY, int speed, float direction, UnitIcon icon) {
        super(size, baseDamage, xp, posX, posY, speed, direction, icon);
        formation = Formation.line;
    }

    /**
     * Modifies the default damage calculation according to the Cavalry rules.
     * @param target
     * @return
     */
    @Override
    public int calculateDemageAgainst(Unit target) {
        int res = super.calculateDemageAgainst(target);
        if(target.getClass() == Archer.class) res += 5;
        if(target.getFormation() == Formation.tight) res += 1;
        if(target.getFormation() == Formation.loose) res -= 1;
        if(target.getFormation() == Formation.box) res -= 1;
        if(target.getFormation() == Formation.shieldwall) res -= 2;
        if(formation == Formation.wedge) res += 1;
        return res;
    }

    public Formation getFormation(){
        return this.formation;
    }

    public void setFormation(int form){
        if(form == 3) formation = Formation.wedge;
        else formation = Formation.line;
    }

    public String toString(){
        return "Cavalry "+size+" "+baseDamage+" "+xp+" "+posX+" "+posY+" "+speed+" "+direction+" "+formation;
    }
}
