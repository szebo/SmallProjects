package units;

import gui.UnitIcon;
import org.jetbrains.annotations.NotNull;

import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.util.Random;

/**
 * The Unit class contains every method and attribute which are the same for all Units.
 */
public abstract class Unit {

    protected int size;
    protected int baseDamage;
    protected int xp;
    protected int morale;

    protected boolean inBattle, isRetreating;

    protected int posX, posY, targetX, targetY, moveX, moveY;
    protected double direction, targetDirection;
    protected int speed;

    protected Rectangle2D rect;
    protected UnitIcon icon;

    protected boolean aiGaveCommand = false;

    public Unit(int size, int baseDamage, int xp, int posX, int posY, int speed, float direction, UnitIcon icon) {
        this.size = size;
        this.baseDamage = baseDamage;
        this.xp = xp;
        this.morale = 50;
        this.posX = posX;
        this.posY = posY;
        this.speed = speed;
        this.direction = direction;
        this.rect = new Rectangle2D.Double((double)posX-30, (double)posY-20, 60, 40);
        this.targetX = posX;
        this.targetY = posY;
        this.targetDirection = direction;
        this.inBattle = false;
        this.isRetreating = false;
        this.icon = icon;
    }

    //Movement and Rendering------------------------------------------------------

    /**
     * This method draws the Unit on the screen. It sets the rotation, draws the icon of the unit in that rotation.
     * @param g
     */
    public void draw(Graphics g){
        Graphics2D g2 = (Graphics2D) g.create();
        rect.setRect(posX-30, posY-20, 60, 40);
        g2.rotate(direction+Math.PI/2, posX, posY);
        g2.drawImage(icon.image.getScaledInstance(60, 40, Image.SCALE_SMOOTH), posX-30, posY-20, null);
    }

    /**
     * This method is responsible for continous movement of the Unit. First it only rotates on every call.
     * Then it starts moving in that direction, until it reaches the target position.
     */
    public void animate(){
        boolean targetxReached = false, targetyReached = false;
        if(!inBattle) {
            if (direction - 0.05 >= targetDirection) {
                direction -= Math.toRadians(1);
            } else if (direction + 0.05 <= targetDirection) {
                direction += Math.toRadians(1);
            } else {
                if (!inRangeOfPosition(Math.abs(targetX), Math.abs(posX), 5)) {
                    posX += moveX;
                }
                else targetxReached = true;
                if (!inRangeOfPosition(Math.abs(targetY), Math.abs(posY), 5)) {
                    posY += moveY;
                }
                else targetyReached = true;
                if(targetxReached && targetyReached && isRetreating) isRetreating = false;
                if(targetxReached && targetyReached && aiGaveCommand) aiGaveCommand = false;
            }
        }
    }

    /**
     * The method sets the target coordinates, and the target direction of the Unit.
     * Also calculates a vector with which tha animate method can change the coordinates later.
     * @param target
     */
    public void moveCommand(Point target) {
        targetDirection = -Math.atan2(-(target.y-posY), (target.x-posX));
        moveX = moveCoords(speed*Math.cos(-targetDirection));
        moveY = moveCoords(-(speed*Math.sin(-targetDirection)));

        targetX = target.x;
        targetY = target.y;
    }

    //Combat Methods-----------------------------------------------------

    /**
     * This is the basic damage a Unit deals to the target.
     * @param target
     * @return
     */
    public int calculateDemageAgainst(Unit target){
        int res = baseDamage * size * xp / 1000 + 1;
        return res;
    }

    /**
     * Makes the Unit take damage to the size and morale.
     * @param dmg
     */
    public void takeDemage(int dmg){
        size -= dmg;
        morale -= dmg/xp;
    }

    /**
     * Sets up a retreat move that cannot be canceled. The Unit moves to a random position in a range between 50, 100 pixels.
     */
    public void retreat(){
        if(morale < 10){
            Random r = new Random();
            int x = posX + r.nextInt(50, 100) * (r.nextInt(2) == 1 ? -1 : 1);
            int y = posY + r.nextInt(50, 100) * (r.nextInt(2) == 1 ? -1 : 1);
            moveCommand(new Point(x, y));
        }
        inBattle = false;
        isRetreating = true;
    }

    /**
     * Checks if the Unit has collided with an other one.
     * @param other
     * @return Returns the other if they have collided.
     */
    public Unit collidedWith(@NotNull Unit other){
        if(other.getRect().intersects(this.rect)) return other;
        else return null;
    }

    /**
     * Getters and Setters
     */
    public void setInBattle(boolean b){
        inBattle = b;
    }

    public void increaseXp(int xp) { this.xp += xp; }

    public void setAiGaveCommand(boolean b){ this.aiGaveCommand = b; }

    public abstract void setFormation(int form);

    public boolean isInBattle(){
        return inBattle;
    }

    public int getSize(){
        return size;
    }

    public int getMorale(){
        return morale;
    }

    public boolean isRetreating(){
        return this.isRetreating;
    }

    public Rectangle2D getRect(){
        return rect;
    }

    public boolean hasAiGaveCommand(){
        return aiGaveCommand;
    }

    public abstract Formation getFormation();

    public Point getPos() {
        return new Point(posX, posY);
    }

    //Assistance Methdods------------------------------------------------------------

    /**
     * Checks if a is in range of b. Used to see if the Unit has reached the target position.
     * @param a Current coordinate
     * @param b Target coordinate
     * @param range
     * @return
     */
    protected boolean inRangeOfPosition(double a, double b, double range) {
        if (a - range <= b && a + range >= b) return true;
        return false;
    }

    /**
     * Makes the given numbers absolute at least 1. Used for calculating the move coordinates.
     * @param x
     * @return
     */
    protected int moveCoords(double x){
        int res;
        if(x < 0){
            if(x > -1) res = -1;
            else res = (int)Math.floor(x);
        }
        else{
            if(x < 1) res = 1;
            else res = (int)Math.floor(x);
        }
        return res;
    }

    /**
     * These are the achievable formations on Units.
     */
    public enum Formation {
        tight, loose, wedge, line, box, shieldwall
    }

    /**
     * Changes the string to an Integer value of the formation.
     * @param s
     * @return
     */
    public static int readFormation(String s){
        switch (s) {
            case "tight":
                return 1;
            case "loose":
                return 2;
            case "wedge":
                return 3;
            case "line":
                return 4;
            case "box":
                return 5;
            case "shieldwall":
                return 6;
            default:
                return -1;
        }
    }
}
