package units;

/**
 * The Battle class extends the Thread class, so it can run constantly and wait 1 second every loop until it ends.
 */
public class Battle extends Thread {

    public Unit playerUnit;
    public Unit enemyUnit;

    public Battle(Unit player, Unit enemy){
        this.playerUnit = player;
        this.enemyUnit = enemy;
    }

    /**
     * As long as the battle thread runs, every second it makes both Units take damage, always recalculating it.
     * If a Unit's size goes below 3 it gets destroyed. If the morale gets below 10 it retreats.
     * The battle ends either way.
     */
    @Override
    public void run() {
        try {
            while(playerUnit != null && enemyUnit != null){
                int d1 = playerUnit.calculateDemageAgainst(enemyUnit);
                int d2 = enemyUnit.calculateDemageAgainst(playerUnit);
                System.out.println("Player Health: " + playerUnit.getSize() + ", Player Morale: " + playerUnit.getMorale() + ", Demage:" + d1);
                System.out.println("Enemy Health: " + enemyUnit.getSize() + ", Enemy Morale: " + enemyUnit.getMorale() + ", Demage: " + d2);
                playerUnit.takeDemage(d2);
                enemyUnit.takeDemage(d1);
                if(playerUnit.getSize() < 3 || playerUnit.getMorale() < 10){
                    playerUnit.retreat();
                    playerUnit = null;
                    break;
                }
                if(enemyUnit.getSize() < 3 || enemyUnit.getMorale() < 10){
                    enemyUnit.retreat();
                    enemyUnit = null;
                    break;
                }
                sleep(1000);
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        if(enemyUnit == null) {
            playerUnit.setInBattle(false);
            playerUnit.increaseXp(1);
        }
        if(playerUnit == null) {
            enemyUnit.setInBattle(false);
            enemyUnit.increaseXp(1);
        }
    }
}
