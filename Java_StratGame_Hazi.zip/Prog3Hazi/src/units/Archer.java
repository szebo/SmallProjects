package units;

import gui.UnitIcon;

public class Archer extends Unit {

    private Formation formation;

    public Archer(int size, int baseDamage, int xp, int posX, int posY, int speed, float direction, UnitIcon icon) {
        super(size, baseDamage, xp, posX, posY, speed, direction, icon);
        this.formation = Formation.tight;
    }

    /**
     * Modifies the default damage calculation according to the Archer rules.
     * @param target
     * @return
     */
    @Override
    public int calculateDemageAgainst(Unit target) {
        int res = super.calculateDemageAgainst(target);
        if(target.getClass() == Infantry.class) res += 5;
        if(target.getFormation() == Formation.shieldwall) res -= 2;
        if(target.getFormation() == Formation.box) res += 1;
        return res;
    }

    public Formation getFormation(){
        return this.formation;
    }

    public void setFormation(int form){
        if(form == 1) formation = Formation.tight;
        else formation = Formation.loose;
    }

    public String toString(){
        return "Archer "+size+" "+baseDamage+" "+xp+" "+posX+" "+posY+" "+speed+" "+direction+" "+formation;
    }
}
