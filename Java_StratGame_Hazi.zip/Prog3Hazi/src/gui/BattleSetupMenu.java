package gui;

import main.Main;
import units.Archer;
import units.Cavalry;
import units.Infantry;

import javax.swing.*;
import java.awt.*;

/**
 * This class is responsible for creating the menu, where you can setup both teams for the simulation,
 * and actually putting all the desired units into their specific lists.
 */
public class BattleSetupMenu extends JPanel {

    /**
     * These JTextFields hold the number of troops we want on the battlefield.
     */
    private JTextField t1 = new JTextField("1", 2);
    private JTextField t2 = new JTextField("1", 2);
    private JTextField t3 = new JTextField("1", 2);

    private JTextField t4 = new JTextField("1", 2);
    private JTextField t5 = new JTextField("1", 2);
    private JTextField t6 = new JTextField("1", 2);

    /**
     * The constructor adds every swing component to the menu.
     */
    public BattleSetupMenu(){
        GridLayout layout = new GridLayout(3, 1);
        setLayout(layout);
        t1.setEditable(true); t2.setEditable(true); t3.setEditable(true); t4.setEditable(true); t5.setEditable(true); t6.setEditable(true);

        JPanel upper, mid, lower;
        upper = new JPanel();
        mid = new JPanel();
        lower = new JPanel();

        JLabel l1 = new JLabel("Player:");
        JLabel l2 = new JLabel("Infantry:");
        JLabel l3 = new JLabel("Cavalry:");
        JLabel l4 = new JLabel("Archer");
        upper.add(l1); upper.add(l2); upper.add(t1); upper.add(l3); upper.add(t2); upper.add(l4); upper.add(t3);

        JLabel l5 = new JLabel("Enemy:");
        JLabel l6 = new JLabel("Infantry:");
        JLabel l7 = new JLabel("Cavalry:");
        JLabel l8 = new JLabel("Archer");
        mid.add(l5); mid.add(l6); mid.add(t4); mid.add(l7); mid.add(t5); mid.add(l8); mid.add(t6);

        JButton start = new JButton("Start");
        start.addActionListener(Main.window);
        lower.add(start);

        add(upper);
        add(mid);
        add(lower);
    }

    /**
     * This method puts the right amount of units in both playerUnits and enemyUnits lists.
     * It takes the amounts from the Setup menu.
     * Positions are calculated according to the number of units that need to be drawn.
     */
    public void setupBattle(){
        int pInfNum = Integer.parseInt(t1.getText());
        for(int i = 0; i < pInfNum; i++){
            Main.playerUnits.add(new Infantry(30, 30,1,200+i*70,600, 1, -(float)Math.PI/2, new UnitIcon("InfantryIcon.jpg")));
        }
        int pCavNum = Integer.parseInt(t2.getText());
        for(int i = 0; i < pCavNum; i++){
            Main.playerUnits.add(new Cavalry(30, 30,1,200+i*70 + pInfNum*80,600, 2, -(float)Math.PI/2, new UnitIcon("CavalryIcon.jpg")));
        }
        int pArchNum = Integer.parseInt(t3.getText());
        for(int i = 0; i < pArchNum; i++){
            Main.playerUnits.add(new Archer(30, 30,1,200+i*70 + pCavNum*80 + pInfNum*80,600, 1, -(float)Math.PI/2, new UnitIcon("ArcherIcon.jpg")));
        }

        int eInfNum = Integer.parseInt(t4.getText());
        for(int i = 0; i < eInfNum; i++){
            Main.enemyUnits.add(new Infantry(30, 30,1,200+i*70,100, 1, (float)Math.PI/2, new UnitIcon("InfantryIcon2.jpg")));
        }
        int eCavNum = Integer.parseInt(t5.getText());
        for(int i = 0; i < eCavNum; i++){
            Main.enemyUnits.add(new Cavalry(30, 30,1,200+i*70 + eInfNum*80,100, 2, (float)Math.PI/2, new UnitIcon("CavalryIcon2.jpg")));
        }
        int eArchNum = Integer.parseInt(t6.getText());
        for(int i = 0; i < eArchNum; i++){
            Main.enemyUnits.add(new Archer(30, 30,1,200+i*70 + eCavNum*80 + eInfNum*80,100, 1, (float)Math.PI/2, new UnitIcon("ArcherIcon2.jpg")));
        }
    }
}
