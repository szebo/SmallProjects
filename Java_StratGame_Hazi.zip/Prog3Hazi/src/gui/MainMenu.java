package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

/**
 * This class is a container for the main menu. Puts three buttons into position.
 */
public class MainMenu extends JPanel {

    /**
     * The constructor takes an ActionListener as parameter which will be listening to the buttons.
     * Puts the Play, Exit, and Load buttons in the correct position, using a GridBagLayout.
     * @param listener The ActionListener for the buttons.
     */
    public MainMenu(ActionListener listener){

        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();

        JButton playButton = new JButton("Play");
        playButton.addActionListener(listener);

        JButton exitButton = new JButton("Exit");
        exitButton.addActionListener(listener);

        JButton loadButton = new JButton("Load");
        loadButton.addActionListener(listener);


        c.gridx = 1;
        c.gridy = 0;
        add(playButton, c);
        c.gridy = GridBagConstraints.RELATIVE;
        add(loadButton, c);
        c.gridy = GridBagConstraints.RELATIVE;
        add(exitButton, c);
    }
}
