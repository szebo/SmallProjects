package gui;

import ai.AI;
import main.Main;
import units.Battle;
import units.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * This class is the mainloop of the game. Holds a private list of all the units in the game, for faster rendering.
 * It is an ActionListener which is only added to a Timer, that makes the loop.
 * It is also a MouseListener so the player can click on their Units and give them orders.
 */
public class GameArea extends JPanel implements ActionListener, MouseListener {

    private List<Unit> units;
    private List<Unit> removables;
    private Timer t;
    private Unit selected;
    private AI ai;
    private FormationListener fl;

    public static List<Battle> battles;

    /**
     * These buttons are used to set the formation of the selected Unit.
     * They only show up on the screen when a Unit is selected, and only those show up, which are available for that type of Unit.
     * They have their own ActionListener.
     */
    private JButton form1 = new JButton("Line");
    private JButton form2 = new JButton("Wedge");
    private JButton form3 = new JButton("Box");
    private JButton form4 = new JButton("Shieldwall");
    private JButton form5 = new JButton("Tight");
    private JButton form6 = new JButton("Loose");

    /**
     * The constructor adds all Components to the GameArea.
     */
    public GameArea(){
        battles = new ArrayList<>();
        t = new Timer(20, this);
        units = new ArrayList<>();
        ai = new AI();
        removables = new ArrayList<>();
        fl = new FormationListener();

        setLayout(new BorderLayout());
        JPanel commands = new JPanel();
        JPanel savePanel = new JPanel();
        form1.addActionListener(fl);
        form2.addActionListener(fl);
        form3.addActionListener(fl);
        form4.addActionListener(fl);
        form5.addActionListener(fl);
        form6.addActionListener(fl);
        JButton save = new JButton("Save"); save.addActionListener(Main.window); savePanel.add(save);
        JButton pause = new JButton("Pause"); pause.addActionListener(Main.window); savePanel.add(pause);
        commands.add(form1); commands.add(form2); commands.add(form3); commands.add(form4); commands.add(form5); commands.add(form6);
        add(commands, BorderLayout.SOUTH);
        add(savePanel, BorderLayout.EAST);
    }

    /**
     * Adds the given List of Units to the private List
     * @param units
     */
    public void addUnits(List<Unit> units){
        this.units.addAll(units);
    }

    /**
     * This if the first part of the main loop. It removes the killed Units from every List,
     * draws every available formation button, removes all finished battles and draws every remaining Unit.
     * @param g
     */
    @Override
    public void paintComponent(Graphics g){
        Graphics2D g2 = (Graphics2D) g;
        super.paintComponent(g2);
        for(Unit u : removables){
            units.remove(u);
            if(Main.playerUnits.contains(u)) Main.playerUnits.remove(u);
            if(Main.enemyUnits.contains(u)) Main.enemyUnits.remove(u);
        }
        if(selected == null){
            form1.setVisible(false);
            form2.setVisible(false);
            form3.setVisible(false);
            form4.setVisible(false);
            form5.setVisible(false);
            form6.setVisible(false);
        }
        else {
            if (selected.getClass() == Archer.class) {
                form1.setVisible(false);
                form2.setVisible(false);
                form3.setVisible(false);
                form4.setVisible(false);
                form5.setVisible(true);
                form6.setVisible(true);
            } else if (selected.getClass() == Infantry.class) {
                form1.setVisible(true);
                form2.setVisible(false);
                form3.setVisible(true);
                form4.setVisible(true);
                form5.setVisible(false);
                form6.setVisible(false);
            } else if (selected.getClass() == Cavalry.class) {
                form1.setVisible(true);
                form2.setVisible(true);
                form3.setVisible(false);
                form4.setVisible(false);
                form5.setVisible(false);
                form6.setVisible(false);
            }
        }
        for(Iterator<Battle> iter = battles.iterator(); iter.hasNext();){
            Battle b = iter.next();
            if(b.getState() == Thread.State.TERMINATED) battles.remove(b);
        }
        removables.clear();
        for(Unit u : units){
            u.draw(g2);
        }
    }

    /**
     * This is the second half of the main loop. Everytime the Timer ticks, this method is called, than it calls the paintComponent method again.
     * Ends the game if either party has lost all of their Units.
     * Controls the AI.
     * Makes every Unit move.
     * Calls the initNewBattle method.
     * @param e
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        if(Main.enemyUnits.isEmpty() || Main.playerUnits.isEmpty()){
            stopGame();
            Main.window.inMenu();
        }
        ai.run();
        for(Unit u : units){
            u.animate();
        }
        initNewBattle();
        repaint();
    }

    /**
     * Iterates through every Unit, and if it finds two that are collided and enemies, than starts a new Battle instance,
     * and adds it to the currently running Batlles' list.
     */
    public synchronized void initNewBattle() {
        for (Iterator<Unit> iter1 = Main.playerUnits.iterator(); iter1.hasNext();) {
            Unit u = iter1.next();
            for (Iterator<Unit> iter2 = Main.enemyUnits.iterator(); iter2.hasNext();) {
                Unit k = iter2.next();
                if(u.getSize() <= 0) {
                    removables.add(u);
                }
                if(k.getSize() <= 0) {
                    removables.add(k);
                }
                if (!u.isRetreating() && !k.isRetreating()) {
                    Unit collided = u.collidedWith(k);
                    if (collided != null) {
                        if (!u.isInBattle() || !k.isInBattle()) {
                            Battle battle = new Battle(u, k);
                            u.setInBattle(true);
                            k.setInBattle(true);
                            battles.add(battle);
                            battle.start();
                            return;
                        }
                    }
                }
            }
        }
    }

    /**
     * Starts the Timer
     */
    public void start(){
        t.start();
    }

    /**
     * Ends the game, and clears Unit lists.
     */
    public void stopGame(){
        t.removeActionListener(this);
        t.stop();
        Main.enemyUnits.clear();
        Main.playerUnits.clear();
        units.clear();
    }

    /**
     * Pauses the timer, or restarts it.
     */
    public void pause(){
        if(t.isRunning()) t.stop();
        else t.start();
    }

    /**
     * Responds to MouseClicks. Goes through the playerUnits list, and if any of the Units contain the point at which the click happened, than makes that Unit selected.
     * If a Unit is already selected at the time of the click, then it gives a move command to that Unit.
     * @param e
     */
    @Override
    public void mouseClicked(MouseEvent e) {
        for(Unit u : Main.playerUnits){
            if(!u.isRetreating()) {
                Point mouse = e.getPoint();
                mouse.y -= 20;
                if (e.getButton() == MouseEvent.BUTTON1 && u.getRect().contains(mouse)) {
                    selected = u;
                }
                if (e.getButton() == MouseEvent.BUTTON3 && selected != null && !selected.getRect().contains(mouse)) {
                    selected.moveCommand(mouse);
                    selected = null;
                }
            }
        }
    }

    public Unit getSelected(){
        return selected;
    }

    public Timer getT(){
        return t;
    }

    /**
     * This is a separate ActionListener class only for the formation buttons.
     */
    private class FormationListener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            JButton button = (JButton) e.getSource();
            if(button.getText().equals("Line")){
                selected.setFormation(4);
            }
            if(button.getText().equals("Wedge")){
                selected.setFormation(3);
            }
            if(button.getText().equals("Box")){
                selected.setFormation(5);
            }
            if(button.getText().equals("Shieldwall")){
                selected.setFormation(6);
            }
            if(button.getText().equals("Tight")){
                selected.setFormation(1);
            }
            if(button.getText().equals("Loose")){
                selected.setFormation(2);
            }
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {}
    @Override
    public void mouseReleased(MouseEvent e) {}
    @Override
    public void mouseEntered(MouseEvent e) {}
    @Override
    public void mouseExited(MouseEvent e) {}
}
