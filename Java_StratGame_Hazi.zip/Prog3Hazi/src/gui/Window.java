package gui;

import main.Main;
import units.Archer;
import units.Cavalry;
import units.Infantry;
import units.Unit;

import javax.swing.*;
import java.util.List;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;

/**
 * The Window class is responsible for changing menus, loading and saving simulations
 * and responding to most of the buttons.
 * It implements the ActionListener interface for button handling.
 * It's derived from the JFrame class to use the Java Swing system.
 */
public class Window extends JFrame implements ActionListener {

    private MainMenu mainMenu;
    private GameArea gameArea;
    private BattleSetupMenu battleSetupMenu;
    private JPanel cards;
    private boolean playing;
    private String currentCard;

    /**
     * Constructor for the window, sets the size, the name and the location of the window.
     * The location is calculated to be in the middle of the screen.
     * The windows uses a CardLayout system, but it cannot be set directly to the JFrame, so instead I'm using a JPanel as my layout container
     * and put that into the JFrame.
     *
     * @param name   The name of the window, shown in the upper left corner.
     * @param width  The width of the window, integer value.
     * @param height The height of the window, integer value.
     */
    public Window(String name, int width, int height){
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(width, height);
        setName(name);
        setLocation(((int)Toolkit.getDefaultToolkit().getScreenSize().getWidth()-width)/2, ((int)Toolkit.getDefaultToolkit().getScreenSize().getHeight()-height)/2);
        cards = new JPanel(new CardLayout());
    }

    /**
     * Initializes the menus and the gamearea, and sets the layout of the window.
     */
    public void init(){
        mainMenu = new MainMenu(this);
        gameArea = new GameArea();
        battleSetupMenu = new BattleSetupMenu();
        this.add(cards);
        cards.add(mainMenu, "MainMenu");
        cards.add(gameArea, "GameArea");
        cards.add(battleSetupMenu, "SetupMenu");
        addMouseListener(gameArea);
    }

    /**
     * Sets the focus on the main menu, where you can decide to close the game, load a previous save, or start a new one.
     */
    public void inMenu(){
        playing = false;
        mainMenu.setVisible(true);
        battleSetupMenu.setVisible(false);
        gameArea.setVisible(false);
        CardLayout c = (CardLayout)cards.getLayout();
        currentCard = "MainMenu";
        c.show(cards, currentCard);
    }

    /**
     * Sets the focus on the setup menu, where you can set the amount of different troops you want to see on the battlefield.
     */
    public void inSetupMenu(){
        mainMenu.setVisible(false);
        battleSetupMenu.setVisible(true);
        CardLayout c = (CardLayout)cards.getLayout();
        currentCard = "SetupMenu";
        c.show(cards, currentCard);
    }

    /**
     * This method starts a simulation.
     * Makes the Game area visible, and every other menu invisible.
     * Also adds the units to the game's own list, so it is easier to draw them.
     */
    public void startGame(){
        playing = true;
        mainMenu.setVisible(false);
        battleSetupMenu.setVisible(false);
        gameArea.setVisible(true);
        gameArea.addUnits(Main.playerUnits);
        gameArea.addUnits(Main.enemyUnits);
        CardLayout c = (CardLayout)cards.getLayout();
        currentCard = "GameArea";
        c.show(cards, currentCard);
        gameArea.start();
    }

    /**
     * Triggered by a button click in the main menu.
     * Loads all the units from save.txt, and puts them in their corresponding lists.
     */
    public void loadGame(){
        try {
            BufferedReader reader = new BufferedReader(new FileReader("save.txt"));
            List<String> lines = reader.lines().toList();
            boolean readingEnemy = false;
            for(int i = 0; i < lines.size(); i++){
                String[] splitLine = lines.get(i).split(" ");
                if(splitLine[0].contains("EnemyUnits")) readingEnemy = true;
                if(!readingEnemy){
                    if(splitLine[0].equals("Infantry")){
                        Unit unit = new Infantry(Integer.parseInt(splitLine[1]), Integer.parseInt(splitLine[2]), Integer.parseInt(splitLine[3]), Integer.parseInt(splitLine[4]), Integer.parseInt(splitLine[5]), Integer.parseInt(splitLine[6]), Float.parseFloat(splitLine[7]), new UnitIcon("InfantryIcon.jpg"));
                        unit.setFormation(Unit.readFormation(splitLine[8]));
                        Main.playerUnits.add(unit);
                    }
                    if(splitLine[0].equals("Archer")){
                        Unit unit = new Archer(Integer.parseInt(splitLine[1]), Integer.parseInt(splitLine[2]), Integer.parseInt(splitLine[3]), Integer.parseInt(splitLine[4]), Integer.parseInt(splitLine[5]), Integer.parseInt(splitLine[6]), Float.parseFloat(splitLine[7]), new UnitIcon("ArcherIcon.jpg"));
                        unit.setFormation(Unit.readFormation(splitLine[8]));
                        Main.playerUnits.add(unit);
                    }
                    if(splitLine[0].equals("Cavalry")){
                        Unit unit = new Cavalry(Integer.parseInt(splitLine[1]), Integer.parseInt(splitLine[2]), Integer.parseInt(splitLine[3]), Integer.parseInt(splitLine[4]), Integer.parseInt(splitLine[5]), Integer.parseInt(splitLine[6]), Float.parseFloat(splitLine[7]), new UnitIcon("CavalryIcon.jpg"));
                        unit.setFormation(Unit.readFormation(splitLine[8]));
                        Main.playerUnits.add(unit);
                    }
                }
                else{
                    if(splitLine[0].equals("Infantry")){
                        Unit unit = new Infantry(Integer.parseInt(splitLine[1]), Integer.parseInt(splitLine[2]), Integer.parseInt(splitLine[3]), Integer.parseInt(splitLine[4]), Integer.parseInt(splitLine[5]), Integer.parseInt(splitLine[6]), Float.parseFloat(splitLine[7]), new UnitIcon("InfantryIcon2.jpg"));
                        unit.setFormation(Unit.readFormation(splitLine[8]));
                        Main.enemyUnits.add(unit);
                    }
                    if(splitLine[0].equals("Archer")){
                        Unit unit = new Archer(Integer.parseInt(splitLine[1]), Integer.parseInt(splitLine[2]), Integer.parseInt(splitLine[3]), Integer.parseInt(splitLine[4]), Integer.parseInt(splitLine[5]), Integer.parseInt(splitLine[6]), Float.parseFloat(splitLine[7]), new UnitIcon("ArcherIcon2.jpg"));
                        unit.setFormation(Unit.readFormation(splitLine[8]));
                        Main.enemyUnits.add(unit);
                    }
                    if(splitLine[0].equals("Cavalry")){
                        Unit unit = new Cavalry(Integer.parseInt(splitLine[1]), Integer.parseInt(splitLine[2]), Integer.parseInt(splitLine[3]), Integer.parseInt(splitLine[4]), Integer.parseInt(splitLine[5]), Integer.parseInt(splitLine[6]), Float.parseFloat(splitLine[7]), new UnitIcon("CavalryIcon2.jpg"));
                        unit.setFormation(Unit.readFormation(splitLine[8]));
                        Main.enemyUnits.add(unit);
                    }
                }
            }
            reader.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        startGame();
    }

    /**
     * Triggered by clicking the Save button while playing a simulation.
     * Takes the current playerUnits and enemyUnits lists from the Main class
     * and writes them out into save.txt
     */
    public void saveGame(){
        if(playing){
            try {
                BufferedWriter writer = new BufferedWriter(new FileWriter("save.txt"));
                writer.write("PlayerUnits\n");
                for(Unit u : Main.playerUnits){
                    writer.write(u.toString());
                    writer.write("\n");
                }
                writer.write("EnemyUnits\n");
                for(Unit u : Main.enemyUnits){
                    writer.write(u.toString());
                    writer.write("\n");
                }
                writer.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * This method needed for tha buttons. The class is made to be an ActionListener itself,
     * and responds to every button in the menus.
     *
     * @param e the ActionEvent which has been sent by the button.
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        JButton button = (JButton) e.getSource();
        if(button.getText().equals("Exit")){
            dispose();
        }
        if(button.getText().equals("Play")){
            inSetupMenu();
        }
        if(button.getText().equals("Start")){
            System.out.println("Start");
            battleSetupMenu.setupBattle();
            startGame();
        }
        if(button.getText().equals("Load")){
            loadGame();
        }
        if(button.getText().equals("Save")){
            saveGame();
        }
        if(button.getText().equals("Pause")){
            gameArea.pause();
        }
    }

    /**
     * Returns the current menu name, that is shown in the window.
     * @return
     */
    public String getCurrentCard(){
        return currentCard;
    }

}
