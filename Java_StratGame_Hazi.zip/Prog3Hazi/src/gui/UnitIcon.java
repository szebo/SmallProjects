package gui;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;

/**
 * This class loads and stores Unit icons which then can be drawn by the Unit's draw method.
 */
public class UnitIcon {
    public BufferedImage image;

    public UnitIcon(String file){
        try {
            URL url = getClass().getResource("/resources/"+file);
            image = ImageIO.read(url);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
