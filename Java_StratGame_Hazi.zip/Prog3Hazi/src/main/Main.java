package main;

import gui.Window;
import units.Unit;

import java.util.ArrayList;
import java.util.List;

public class Main {

    public static List<Unit> playerUnits = new ArrayList<>();
    public static List<Unit> enemyUnits = new ArrayList<>();
    public static Window window;

    public static void main(String[] args){
        window = new Window("Nagy Hazi", 1280, 720);
        window.init();
        window.setVisible(true);
        window.inMenu();
    }
}
