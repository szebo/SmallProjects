package ai;

import main.Main;
import units.Unit;

import java.util.Random;

public class AI{

    private int strategy;

    /**
     * When the AI instance is created it randomly decides on a strategy.
     * Either defensive (doesn't move) or aggressive (targets player units).
     */
    public AI(){
        Random r = new Random();
        strategy = r.nextInt(2);
    }

    /**
     * If the AI's strategy is 1, or aggressive, it gives all the enemy units a randomly chosen player unit's coordinates as a moveCommand.
     * This only happens when there are Units without command.
     */
    public void run(){
        if(strategy == 1){
            for (Unit u : Main.enemyUnits) {
                if (!u.isInBattle() && !u.isRetreating() && !u.hasAiGaveCommand()) {
                    Random r = new Random();
                    Unit target = Main.playerUnits.get(r.nextInt(Main.playerUnits.size()));
                    u.moveCommand(target.getRect().getBounds().getLocation());
                    u.setAiGaveCommand(true);
                }
            }
        }
    }
}
